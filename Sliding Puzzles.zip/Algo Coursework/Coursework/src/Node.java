public class Node {
    // Instance variables to store the coordinates
    int x, y;

    // Constructor to initialize the Node object with x and y coordinates
    public Node(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Override hashCode method to generate a unique hash code for each Node object
    @Override
    public int hashCode() {
        // Generate hash code based on the concatenation of x and y coordinates
        return (x + "," + y).hashCode();
    }

    // Override equals method to compare two Node objects for equality
    @Override
    public boolean equals(Object obj) {
        // Check if the objects are the same instance
        if (this == obj)
            return true;
        // Check if the object is null or not of the same class
        if (obj == null || getClass() != obj.getClass())
            return false;
        // Cast the object to Node class for comparison
        Node node = (Node) obj;
        // Compare the x and y coordinates for equality
        return x == node.x && y == node.y;
    }

    // Override toString method to generate a string representation of the Node object
    @Override
    public String toString() {
        // Return a string in the format "(x, y)" representing the coordinates
        return "(" + x + ", " + y + ")";
    }

    public String getKey() {
        return x + "," + y;
    }
}
