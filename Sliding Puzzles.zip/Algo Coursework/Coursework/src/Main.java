import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            // Specify the path to the maze file
            String filePath = "examples/maze25_1.txt";

            // Start the timer
            long startTime = System.currentTimeMillis();

            // Create a parser instance to read the maze file
            Parser parser = new Parser();
            // Load the maze data into a 2D grid
            int[][] grid = parser.loadMapFromFile(filePath);
            // Print a message indicating the grid has been loaded
            System.out.println("Maze loaded:");
            // Print the grid
//            printGrid(grid);

            Node start = null;
            Node finish = null;

            // Find start and finish positions in the maze
            for (int i = 0; i < grid.length; i++) {
                for (int j = 0; j < grid[i].length; j++) {
                    // Code 2 represents the start position in the maze
                    if (grid[i][j] == 2) {
                        start = new Node(j, i); // Store the start node coordinates
                    }
                    // Code 3 represents the finish position in the maze
                    else if (grid[i][j] == 3) {
                        finish = new Node(j, i); // Store the finish node coordinates
                    }
                }
            }

            // Check if both start and finish nodes were found
            if (start == null || finish == null) {
                System.out.println("Start or finish nodes not found in the grid.");
                return;
            }

            // Print the coordinates of the start and finish nodes
            System.out.println("Start at: " + start);
            System.out.println("Finish at: " + finish);

            // Create a graph representation of the maze
            Graph graph = new Graph(grid);



            // Find a path from the start to the finish node using breadth-first search
            graph.breadthFirstSearch(start, finish);

            // Stop the timer and calculate the elapsed time
            long endTime = System.currentTimeMillis();
            long elapsedTime = endTime - startTime;

            // Print the elapsed time
            System.out.println("Elapsed Time: " + elapsedTime + " milliseconds");
        }
        // Catch any IO exceptions that occur during file reading
        catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Method to print the grid
    private static void printGrid(int[][] grid) {
        // Iterate through each row in the grid
        for (int[] row : grid) {
            // Iterate through each cell in the row
            for (int cell : row) {
                // Print the value of the cell followed by a space
                System.out.print(cell + " ");
            }
            // Move to the next line after printing each row
            System.out.println();
        }
    }
}
