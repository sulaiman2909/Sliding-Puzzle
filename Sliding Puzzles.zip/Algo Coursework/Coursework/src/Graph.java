import java.util.*;

public class Graph {
    // Adjacency list to store the graph representation
    private Map<Node, List<Node>> adjacencyList;
    // 2D grid representing the maze
    private int[][] grid;

    // Constructor to initialize the graph with the given grid
    public Graph(int[][] grid) {
        this.grid = grid;
        adjacencyList = new HashMap<>();
        createAdjacencyList(); // Create the adjacency list representation
    }

    // Method to create the adjacency list from the grid
    private void createAdjacencyList() {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                if (grid[i][j] != 1) {  // If the cell is not an obstacle
                    Node n = new Node(j, i); // Create a Node object for the current cell
                    adjacencyList.put(n, getValidMoves(n)); // Add valid moves from this node to the adjacency list
                }
            }
        }
    }

    // Method to get valid moves from a given node
    private List<Node> getValidMoves(Node node) {
        List<Node> validMoves = new ArrayList<>();
        int[][] directions = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}}; // Possible movement directions (Down, Right, Up, Left)
        for (int[] dir : directions) {
            int x = node.x, y = node.y;
            // Keep moving in the current direction until an obstacle or finish node is reached
            while (canMove(x + dir[0], y + dir[1])) {
                x += dir[0];
                y += dir[1];
                if (grid[y][x] == 3) {  // If it's the finish node, stop here
                    break;
                }
            }
            if (x != node.x || y != node.y) { // Add only if there is a valid move in the direction
                validMoves.add(new Node(x, y));
            }
        }
        return validMoves;
    }

    // Helper method to check if movement to a given position is possible
    private boolean canMove(int x, int y) {
        return x >= 0 && x < grid[0].length && y >= 0 && y < grid.length && grid[y][x] != 1;
    }

    // Method to perform breadth-first search to find the shortest path
    public void breadthFirstSearch(Node start, Node finish) {
        Queue<Node> queue = new LinkedList<>();
        Map<Node, Node> cameFrom = new HashMap<>();
        queue.add(start);
        cameFrom.put(start, null);

        while (!queue.isEmpty()) {
            Node current = queue.poll();
            if (current.equals(finish)) {
                printPath(cameFrom, finish); // Print the path if finish node is reached
                return;
            }

            for (Node neighbor : adjacencyList.getOrDefault(current, new ArrayList<>())) {
                if (!cameFrom.containsKey(neighbor)) {
                    queue.add(neighbor);
                    cameFrom.put(neighbor, current);
                }
            }
        }
        System.out.println("No path found.");
    }

    // Method to print the path from start to finish
    private void printPath(Map<Node, Node> cameFrom, Node current) {
        List<Node> path = new ArrayList<>();
        Node step = current;
        while (step != null) {
            path.add(step);
            step = cameFrom.get(step);
        }
        Collections.reverse(path);
        System.out.println("Path found:");
        for (int i = 0; i < path.size(); i++) {
            Node prev = (i == 0) ? null : path.get(i - 1);
            Node next = path.get(i);
            if (prev != null) {
                System.out.println((i + 1) + ". " + getDirection(prev, next) + " to " + next);
            } else {
                System.out.println((i + 1) + ". Start at " + next);
            }
        }
    }

    // Helper method to determine the movement direction
    private String getDirection(Node current, Node neighbor) {
        if (current.x < neighbor.x) {
            return "Moved right";
        } else if (current.x > neighbor.x) {
            return "Moved left";
        } else if (current.y < neighbor.y) {
            return "Moved down";
        } else {
            return "Moved up";
        }
    }
}
