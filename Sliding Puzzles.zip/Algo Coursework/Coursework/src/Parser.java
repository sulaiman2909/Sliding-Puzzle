import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Parser {

    // Method to load a map from a file and parse it into a 2D integer array
    public static int[][] loadMapFromFile(String filePath) throws IOException {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }

        if (lines.isEmpty()) {
            throw new IOException("The file is empty.");
        }

        int height = lines.size();
        int width = lines.stream().mapToInt(String::length).max().orElseThrow(
                () -> new IOException("Error determining the width of the map.")
        );
        int[][] grid = new int[height][width];

        for (int i = 0; i < height; i++) {
            String currentLine = lines.get(i);
            for (int j = 0; j < currentLine.length(); j++) { // Only loop over the length of the current line
                grid[i][j] = charToInt(currentLine.charAt(j));
            }
            for (int j = currentLine.length(); j < width; j++) { // Fill the rest of the row with default value if line is short
                grid[i][j] = 0; // Or any default value indicating empty space or non-obstacle
            }
        }

        return grid;
    }





    // Helper method to convert characters to their respective integer codes
    private static int charToInt(char c) {
        switch (c) {
            case '.':
                return 0;
            case '0':
                return 1;
            case 'S':
                return 2;
            case 'F':
                return 3;
            default:
                return 0; // Default to 0 if character is unrecognized
        }
    }
}